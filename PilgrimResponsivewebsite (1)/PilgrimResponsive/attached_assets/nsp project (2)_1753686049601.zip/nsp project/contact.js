document.getElementById("contactForm").addEventListener("submit", function (e) {
  e.preventDefault();

  const name = document.getElementById("name").value.trim();
  const email = document.getElementById("email").value.trim();
  const message = document.getElementById("message").value.trim();

  // Show data below
  document.getElementById("submittedData").innerHTML = `
    <h3>Message Preview</h3>
    <p><strong>Name:</strong> ${name}</p>
    <p><strong>Email:</strong> ${email}</p>
    <p><strong>Message:</strong> ${message}</p>
  `;

  // WhatsApp link create
  const whatsappNumber = "919982325230"; // Your WhatsApp number without + (replace with yours)
  const whatsappMsg = `Name: ${name}%0AEmail: ${email}%0AMessage: ${message}`;
  const whatsappURL = `https://wa.me/${whatsappNumber}?text=${whatsappMsg}`;

  const whatsappBtn = document.getElementById("whatsappLink");
  whatsappBtn.href = whatsappURL;
  whatsappBtn.style.display = "inline-block";

  // Clear form
  document.getElementById("contactForm").reset();
});
